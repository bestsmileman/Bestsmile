# Hotkey Manager v7 - PDF 개발지침 기반 구현

## 특징
- 일반앱/간이앱 구분 가능
- 간이/중복/우선 항목용 셀 존재
- 클릭 수정, 정렬, 저장, 언어 전환 준비
- 향후: 색상 원 토글, 자동중복 감지, HTML 출력 추가 가능

## 실행 방법
```bash
pip install tksheet
python hotkey_manager.py
```
